package Software;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/AddAdvertisment"})
public class AddAdvertisement extends HttpServlet {
public AddAdvertisement(){
    super();
}
       
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
 String id=request.getParameter("id");
 String Advname1 = request.getParameter("name1");
  
  String Advdesc1 = request.getParameter("description1");
  String Advtime1 = request.getParameter("time1");
  
 String Advname2 = request.getParameter("name2");
  
  String Advdesc2 = request.getParameter("description2");
  String Advtime2 = request.getParameter("time2");
  
  response.setContentType("text/html");
 PrintWriter out = response.getWriter();
  if (Advname1.isEmpty() || Advdesc1.isEmpty() || Advtime1.isEmpty()) {
      request.setAttribute("id",id);
  request.setAttribute("description1",Advdesc1);
  request.setAttribute("title1",Advname1);
  request.setAttribute("time1",Advtime1);
  request.setAttribute("description2",Advdesc2);
  request.setAttribute("title2",Advname2);
  request.setAttribute("time2",Advtime2);
   RequestDispatcher rd = request.getRequestDispatcher("AddAdvertisement.jsp");
   out.println("<font color=red>Please add at least 1 advertisment</font>");
   rd.include(request, response);
  } 
  else {
       if ((Integer.parseInt(Advtime1))>3||Integer.parseInt(Advtime1)<=0) {
                request.setAttribute("id",id);
  request.setAttribute("description1",Advdesc1);
  request.setAttribute("title1",Advname1);
  request.setAttribute("time1",Advtime1);
  request.setAttribute("description2",Advdesc2);
  request.setAttribute("title2",Advname2);
  request.setAttribute("time2",Advtime2);
   RequestDispatcher rd = request.getRequestDispatcher("AddAdvertisement.jsp");
   out.println("<font color=red>Please add valid time for the first advertisement</font>");
   rd.include(request, response);
  } 
       else{
           
      int Advertiserid=Integer.parseInt(id);
      int i;
      if(Advtime2.equals("")){
        i=0;
        Advname2="";
        Advdesc2="";
        
      }
      else
      {
          
        i=Integer.parseInt(Advtime2);  
        if (Integer.parseInt(Advtime2)>3||Integer.parseInt(Advtime2)<=0) {
            request.setAttribute("id",id);
  request.setAttribute("description1",Advdesc1);
  request.setAttribute("title1",Advname1);
  request.setAttribute("time1",Advtime1);
  request.setAttribute("description2",Advdesc2);
  request.setAttribute("title2",Advname2);
  request.setAttribute("time2",Advtime2);
   RequestDispatcher rd = request.getRequestDispatcher("AddAdvertisement.jsp");
   out.println("<font color=red>Please add valid time for the second advertisement</font>");
   rd.include(request, response);}
      
      else{
      int canAdd=0;
       if (Advname2=="") {
                    canAdd=0;
                 }
                 else {
                    canAdd=1;
                    
                 }
    Model m = new Model();
   m.addAdvertisement(Advertiserid, Advname1, Advdesc1 , Integer.parseInt(Advtime1), Advname2, Advdesc2 , i, canAdd);
         
  
   RequestDispatcher rd = request.getRequestDispatcher("Finish.jsp");
    rd.forward(request, response);
       }
       }
       }
  }
 }
}
 
