package Software;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/payOnline2"})
public class Paid2 extends HttpServlet {  
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 String id= request.getParameter("id");
 String pay= request.getParameter("pay");
 String fees= request.getParameter("fees");
 String title1= request.getParameter("title1");
 String time1= request.getParameter("time1"); 
 String title2= request.getParameter("title2");
 String time2= request.getParameter("time2"); 
 String cardType= request.getParameter("type");
 String Bank= request.getParameter("bank");
 String cardNumber = request.getParameter("cardnumber");
 String securityCode= request.getParameter("secure");
 String nameCard= request.getParameter("namecard"); 
 Model m = new Model();
 PrintWriter out = response.getWriter();
 if(pay.isEmpty()){
      request.setAttribute("id",id);
  request.setAttribute("time1",Integer.parseInt(time1));
  request.setAttribute("title1",title1);
  request.setAttribute("time2",Integer.parseInt(time1));
  request.setAttribute("title2",title2);
  request.setAttribute("fees",(Integer.parseInt(time1)*100)+(Integer.parseInt(time2)*100));
     RequestDispatcher rd = request.getRequestDispatcher("PayFees.jsp");
   out.println("<font color=red>Please pay </font>");
   rd.include(request, response);
 }
 else{
   if(Integer.parseInt(pay)!=Integer.parseInt(fees))//b2e acheck eno int
   {
        request.setAttribute("id",id);
  request.setAttribute("time1",Integer.parseInt(time1));
  request.setAttribute("title1",title1);
  request.setAttribute("time2",Integer.parseInt(time2));
  request.setAttribute("title2",title2);
  request.setAttribute("fees",(Integer.parseInt(time1)*100)+(Integer.parseInt(time2)*100));
       RequestDispatcher rd = request.getRequestDispatcher("PayFees.jsp");
   out.println("<font color=red>Please pay</font>");
   rd.include(request, response);
   }   
  else {
         m.updateAdvertisementForAdv1(Integer.parseInt(id),(Integer.parseInt(time1)*100));
         m.updateAdvertisementForAdv2(Integer.parseInt(id),(Integer.parseInt(time2)*100)); 
         m.addPayingInfo(Integer.parseInt(id),Integer.parseInt(cardNumber), nameCard, Integer.parseInt(securityCode), Bank, cardType,Integer.parseInt(cardNumber), nameCard, Integer.parseInt(securityCode), Bank, cardType);
         RequestDispatcher rd = request.getRequestDispatcher("EveryThingPaid.jsp");
         rd.include(request, response);
  }
 }
 }
}

