package Software;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/AdminEditSites"})
public class GetSites extends HttpServlet {
    
   
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 Model m = new Model();
 Site s=new Site();
        try {
      
             s= m.viewSites();
if(s.name!=null)
{
    request.setAttribute("name",s.name);
    request.setAttribute("address",s.address);
    request.setAttribute("description",s.description);
    request.setAttribute("Stime",s.start);
    request.setAttribute("Etime",s.close);
    request.setAttribute("photo",s.photo);  
    request.setAttribute("type1",s.type1);
    request.setAttribute("type2",s.type2);
    RequestDispatcher rd = request.getRequestDispatcher("ViewSite2.jsp");
    rd.include(request, response);
}
else {
       RequestDispatcher rd = request.getRequestDispatcher("NoMoreSites.jsp");
       rd.include(request, response);
     }
}   
         catch (SQLException ex) {
            Logger.getLogger(AddTourGuide.class.getName()).log(Level.SEVERE, null, ex);
        }
  

  }
}
   
  
  