/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Software;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/payfees"})
public class PayFees  extends HttpServlet {
public PayFees(){
    super();
}
        
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

  String id = request.getParameter("id");
  response.setContentType("text/html");
 PrintWriter out = response.getWriter();
      int check1=0;
    Model m = new Model(); // TODO Auto-generated catch block
  check1= m.getCanAdd(Integer.parseInt(id));
  int check2= m.getpay1(Integer.parseInt(id));
  if(check1==0)
  {
      if(check2==0){
      int time1=m.getTime1(Integer.parseInt(id));
      String title1=m.getTitle1(Integer.parseInt(id));
  request.setAttribute("id",id);
  request.setAttribute("time",time1);
  request.setAttribute("title",title1);
  request.setAttribute("fees",time1*100);
  request.setAttribute("id2",1);
   RequestDispatcher rd = request.getRequestDispatcher("PayFees.jsp");
    rd.forward(request, response);
      }
      else{
           RequestDispatcher rd = request.getRequestDispatcher("Finish.jsp");
    rd.forward(request, response);
      }
  }
  else {
      int check3=m.getpay2(Integer.parseInt(id));
      if(check3==0&check2==0){
  int time1=m.getTime1(Integer.parseInt(id));
  int time2=m.getTime2(Integer.parseInt(id));
  String title1=m.getTitle1(Integer.parseInt(id));
  String title2=m.getTitle2(Integer.parseInt(id));
  request.setAttribute("id",id);
  request.setAttribute("time1",time1);
  request.setAttribute("time2",time2);
  request.setAttribute("title1",title1);
  request.setAttribute("title2",title2);
  request.setAttribute("fees",(time1*100)+(time2*100));
  RequestDispatcher rd = request.getRequestDispatcher("PayFees2.jsp");
  rd.forward(request, response);  
      }
      else{
          if(check3==0){
              int time2=m.getTime2(Integer.parseInt(id));
      String title2=m.getTitle2(Integer.parseInt(id));
  request.setAttribute("id",id);
  request.setAttribute("time",time2);
  request.setAttribute("title",title2);
  request.setAttribute("fees",time2*100);
   request.setAttribute("id2",2);
   RequestDispatcher rd = request.getRequestDispatcher("PayFees.jsp");
    rd.forward(request, response);
          }
          else{
         if(check2==0){
              int time1=m.getTime1(Integer.parseInt(id));
      String title1=m.getTitle1(Integer.parseInt(id));
  request.setAttribute("id",id);
  request.setAttribute("time",time1);
  request.setAttribute("title",title1);
  request.setAttribute("fees",time1*100);
   request.setAttribute("id2",1);
   RequestDispatcher rd = request.getRequestDispatcher("PayFees.jsp");
    rd.forward(request, response);
          }
         else
         {
              RequestDispatcher rd = request.getRequestDispatcher("Finish.jsp");
    rd.forward(request, response);
         }
          }
      }
  }   
 }
}
