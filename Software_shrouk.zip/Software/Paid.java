package Software;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/payOnline"})

public class Paid extends HttpServlet {
    
   
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 String id= request.getParameter("id");
 String id2= request.getParameter("id2");
 String pay= request.getParameter("pay");
 String fees= request.getParameter("fees");
 String title= request.getParameter("title");
 String time= request.getParameter("time");  
 String cardType= request.getParameter("type");
 String Bank= request.getParameter("bank");
 String cardNumber = request.getParameter("cardnumber");
 String securityCode= request.getParameter("secure");
 String nameCard= request.getParameter("namecard"); 
 Model m = new Model();
 PrintWriter out = response.getWriter();
 if(pay.isEmpty()){
      request.setAttribute("id",id);
  request.setAttribute("time",Integer.parseInt(time));
  request.setAttribute("title",title);
  request.setAttribute("fees",Integer.parseInt(time)*100);
   request.setAttribute("id2",id2);
     RequestDispatcher rd = request.getRequestDispatcher("PayFees.jsp");
   out.println("<font color=red>Please pay </font>");
   rd.include(request, response);
 }
 else{
   if(Integer.parseInt(pay)!=Integer.parseInt(fees))//b2e acheck eno int
   {
       request.setAttribute("id",id);
  request.setAttribute("time",Integer.parseInt(time));
  request.setAttribute("title",title);
  request.setAttribute("fees",Integer.parseInt(time)*100);
   request.setAttribute("id2",id2);
       RequestDispatcher rd = request.getRequestDispatcher("PayFees.jsp");
   out.println("<font color=red>Please pay</font>");
   rd.include(request, response);
   }   
  else {
       if(Integer.parseInt(id2)==1){
         m.updateAdvertisementForAdv1(Integer.parseInt(id),Integer.parseInt(pay));
       if(m.payingInfo(Integer.parseInt(id))<0)
       {
           m.addPayingInfo(Integer.parseInt(id),Integer.parseInt(cardNumber), nameCard, Integer.parseInt(securityCode), Bank, cardType, 0, "",0,"","");
       }
       else{
           m.updatePayingInfo(Integer.parseInt(id),Integer.parseInt(cardNumber), nameCard, Integer.parseInt(securityCode), Bank, cardType);
       }
       }
       else{
         m.updateAdvertisementForAdv2(Integer.parseInt(id),Integer.parseInt(pay)); 
         if(m.payingInfo(Integer.parseInt(id))<0)
       {
        m.addPayingInfo(Integer.parseInt(id) ,0, "",0,"","",Integer.parseInt(cardNumber), nameCard, Integer.parseInt(securityCode), Bank, cardType);
       }
         else{
             m.updatePayingInfo2(Integer.parseInt(id),Integer.parseInt(cardNumber), nameCard, Integer.parseInt(securityCode), Bank, cardType); 
         }
       }
        RequestDispatcher rd = request.getRequestDispatcher("EveryThingPaid.jsp");
         rd.include(request, response);
  }
 }
  }
}