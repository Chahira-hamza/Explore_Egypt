package Software;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet(urlPatterns = {"/EditSites"})
@MultipartConfig(maxFileSize = 16177215) 
public class EditSites extends HttpServlet {
    
public EditSites(){
     super();
}
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
 }  

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  String name = request.getParameter("name");
  String addr = request.getParameter("address");
  String desc = request.getParameter("description");
  String start = request.getParameter("Stime");
  String end = request.getParameter("Etime");
  String type1 = request.getParameter("type1");
  String type2 = request.getParameter("type2");
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  Part filePart = request.getPart("photo");
  String fileName=null;
        if(filePart.getSize()<=0){
            fileName = request.getParameter("photo2"); 
        }
        else
        {
           fileName = getFileName(filePart);
        }
        if(type1==null)
        {
            type1 = request.getParameter("typeOld1");
        }
        if(type2==null)
        {
            type2 = request.getParameter("typeOld2");
        }
  // validate given input
  if (name.isEmpty() || addr.isEmpty() || desc.isEmpty() || start.isEmpty() || end.isEmpty() ) {
   RequestDispatcher rd = request.getRequestDispatcher("EditSite.jsp");
   out.println("<font color=red>Please fill all the fields</font>");
   rd.include(request, response);
  } 
  else {

    Model m = new Model(); // TODO Auto-generated catch bloc
    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
       Date ds=null;
       Date de=null;
      try {
          ds=sdf.parse(start);
          de=sdf.parse(end);
      } catch (ParseException ex) {
          Logger.getLogger(AddSites.class.getName()).log(Level.SEVERE, null, ex);
      }
     
   m.updateSite(name, addr,desc ,ds, de,fileName,type1,type2);
   request.setAttribute("name",name);
   request.setAttribute("address",addr);
   request.setAttribute("description",desc);
   request.setAttribute("Stime",start);
   request.setAttribute("Etime",end);
   request.setAttribute("photo",fileName);
   request.setAttribute("type1",type1);
   request.setAttribute("type2",type2);
   RequestDispatcher rd = request.getRequestDispatcher("ViewSite.jsp");
   rd.forward(request, response);
  }
        }
 
private String getFileName(final Part part) {
    for (String content : part.getHeader("content-disposition").split(";")) {
        if (content.trim().startsWith("filename")) {
            return content.substring(
                    content.indexOf('=') + 1).trim().replace("\"", "");
        }
    }
    return null;
}
}