package Software;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */

@WebServlet(urlPatterns = {"/AddTourGuide"})
public class AddTourGuide extends HttpServlet {
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub
      String id= request.getParameter("id");
       String add=request.getParameter("add");
        Model m = new Model(); // TODO Auto-generated catch block
      if(add!=null)
      {
          m.updateuser(Integer.parseInt(id));
      }

           
 UserForAdmin t = new UserForAdmin();
        try {
      
             t= m.viewUser2(t,Integer.parseInt(id),1);
if(t.name!=null)
{
                 request.setAttribute("name",t.name);
                  request.setAttribute("id",t.id);
  if (t.accepted==0 ) {
      
   RequestDispatcher rd = request.getRequestDispatcher("ViewTourGuides.jsp");
   rd.include(request, response);
   
  } 
  else {
       RequestDispatcher rd = request.getRequestDispatcher("DeleteTourGuides.jsp");
   rd.include(request, response);
  }
}   
else{
       RequestDispatcher rd = request.getRequestDispatcher("Finish.jsp");
   rd.include(request, response);
}
    
        } catch (SQLException ex) {
            Logger.getLogger(AddTourGuide.class.getName()).log(Level.SEVERE, null, ex);
        }
  

  }
   
  }