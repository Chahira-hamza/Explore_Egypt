/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Software;



import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/ViewSite"})
@MultipartConfig(maxFileSize = 16177215) 
public class ViewSites extends HttpServlet {
    
public ViewSites(){
     super();
}
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
 }  

 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String name= request.getParameter("name");
  String addr=null;
  String desc=null ;
  String start=null ;
  String end=null ;
  String photo=null;
  
  System.out.println(name);
     Model m = new Model(); // TODO Auto-generated catch block    try {
     Site s=new Site();
     s.name=name;
     
        if(name!=null){   
   s=m.viewSite(s);
        }
        request.setAttribute("name",s.name);
 request.setAttribute("address",s.address);
  request.setAttribute("description",s.description);
  request.setAttribute("Stime",s.start);
   request.setAttribute("Etime",s.close);
  request.setAttribute("photo",s.photo);
         RequestDispatcher rd = request.getRequestDispatcher("EditSite.jsp");
    rd.forward(request, response);
  // m.viewSite(String sname,response);
  
}
}



