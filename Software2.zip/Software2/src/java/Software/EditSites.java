package Software;


import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.String;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import javax.xml.bind.DatatypeConverter;

@WebServlet(urlPatterns = {"/EditSites"})
@MultipartConfig(maxFileSize = 16177215) 
public class EditSites extends HttpServlet {
    
public EditSites(){
     super();
}
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
 }  

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  String name = request.getParameter("name");
  String addr = request.getParameter("address");
  String desc = request.getParameter("description");
  String start = request.getParameter("Stime");
  String end = request.getParameter("Etime");
  
  response.setContentType("text/html");
 PrintWriter out = response.getWriter();
 // obtains the upload file part in this multipart request
 /////////Image
 
        Part filePart = request.getPart("photo");
        
        String savepath= "C:\\Users\\User\\Documents\\NetBeansProjects\\Software2\\web\\images\\";
        
 
        
        
         String photo="";
     File file=new File(savepath);
          file.mkdir();
          String fileName = getFileName(filePart);
        
        
         OutputStream out1 = null;
          
            InputStream filecontent = null;
            
            PrintWriter writer = response.getWriter();
            
        out1 = new FileOutputStream(new File(savepath + File.separator
                + fileName));
        
        filecontent = filePart.getInputStream();
     
 
        int read = 0;
        final byte[] bytes = new byte[1024];
 
        while ((read = filecontent.read(bytes)) != -1) {
            out1.write(bytes, 0, read);
           
            photo=savepath+"/"+fileName;
            
            
        }
        
        
        
       
        
        

  // validate given input
  if (name.isEmpty() || addr.isEmpty() || desc.isEmpty() || start.isEmpty() || end.isEmpty() ) {
   RequestDispatcher rd = request.getRequestDispatcher("AddSite.jsp");
   out.println("<font color=red>Please fill all the fields</font>");
   rd.include(request, response);
  } 
  else {

    Model m = new Model(); // TODO Auto-generated catch bloc
    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
       Date ds=null;
       Date de=null;
      try {
          ds=sdf.parse(start);
          de=sdf.parse(end);
      } catch (ParseException ex) {
          Logger.getLogger(AddSites.class.getName()).log(Level.SEVERE, null, ex);
      }
     
   m.updateSite(name, addr,desc ,ds, de,fileName);
   request.setAttribute("name",name);
 request.setAttribute("address",addr);
  request.setAttribute("description",desc);
  request.setAttribute("Stime",start);
   request.setAttribute("Etime",end);
  request.setAttribute("photo",fileName);
  // m.viewSite(String sname,response);
   RequestDispatcher rd = request.getRequestDispatcher("EditSite.jsp");
    rd.forward(request, response);
  }
    // public static void main(String[] args) throws IOException, InterruptedException {
      //   Model m=new Model();
        // m.addSite("pyramids", "address", "content", 10, 10);
     //}
  
 out.println("shhhh@");
        }
 
private String getFileName(final Part part) {
    final String partHeader = part.getHeader("content-disposition");
    
    for (String content : part.getHeader("content-disposition").split(";")) {
        if (content.trim().startsWith("filename")) {
            return content.substring(
                    content.indexOf('=') + 1).trim().replace("\"", "");
        }
    }
    return null;
}
}