/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Software;

/**
 *
 * @author User
 */
public class Site {
     public String name=null;
    public String address=null;
    public String description=null;
    public String start=null;
    public String close=null;
    public String photo=null;
    public String type1=null;
    public String type2=null;
}
