package Software;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import newpackage.User;

/**
 *
 * @author chahira
 */
@WebServlet(urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        String username, password;

        username = request.getParameter("uname");
        password = request.getParameter("psw");
            response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    int accept = 0;
        Model myModel = new Model();
        
        boolean result = myModel.authenticate(username, password);
        UserForAdmin t = new UserForAdmin();
       int Id=myModel.getUserDetails(username).getUserID();
        try {
            t=myModel.viewUser(t, Id);
           accept=t.accepted;
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (result)
        {
            User user = myModel.getUserDetails(username);
            
            if (user.getUserType() == 0)
            {
                // admin
                request.getSession().setAttribute("user", user);
                response.sendRedirect("AdminHomePage.jsp");
            }
           
            else if ((user.getUserType() == 2)&&(accept==1))
                {
                    int id= myModel.getid(username, password);
                    // advertiser
                    request.setAttribute("id",id);
                    RequestDispatcher rd = request.getRequestDispatcher("AdvertiserHomePage.jsp");
                    rd.forward(request, response);
                }
                else
                {
                    // guest
                    request.getSession().setAttribute("user", user);
                    response.sendRedirect("guest.jsp");
                }
           
        }
        else
        {
             
            RequestDispatcher rd = request.getRequestDispatcher("homepage.jsp");
            out.println("<font color=blue>Wrong password or username</font>");
            rd.forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
