/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Software;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/AdvertiserAddAdvertisement"})
public class CanAddAdvertisement extends HttpServlet {
public CanAddAdvertisement(){
    super();
}
        
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

  String id = request.getParameter("id");
  response.setContentType("text/html");
 PrintWriter out = response.getWriter();
 
      int add=0;
    Model m = new Model(); // TODO Auto-generated catch block
  add= m.getCanAdd(Integer.parseInt(id));
  if(add==0)
  {
  request.setAttribute("id",id);
   RequestDispatcher rd = request.getRequestDispatcher("AddAdvertisement.jsp");
    rd.forward(request, response);
  }
  else {
     RequestDispatcher rd = request.getRequestDispatcher("Finish.jsp");
    rd.forward(request, response);  
  }
    
 }
}
