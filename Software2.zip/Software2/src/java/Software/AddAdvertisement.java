/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Software;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/AddAdvertisment"})
@MultipartConfig(maxFileSize = 16177215) 
public class AddAdvertisement extends HttpServlet {
public AddAdvertisement(){
    super();
}
        
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
  String Advname1 = request.getParameter("name1");
  
  String Advdesc1 = request.getParameter("description1");
  String Advtime1 = request.getParameter("time1");
 String Advname2 = request.getParameter("name2");
  
  String Advdesc2 = request.getParameter("description2");
  String Advtime2 = request.getParameter("time2");
  
  response.setContentType("text/html");
 PrintWriter out = response.getWriter();
 // obtains the upload file part in this multipart request
 /////////Image
 
        Part filePart = request.getPart("photo1");
        Part filePart2 = request.getPart("photo2");
        String savepath= "C:\\Users\\User\\Documents\\NetBeansProjects\\Software2\\web\\images\\";
        
        String photo="";
         String photo2="";
     File file=new File(savepath);
          file.mkdir();
          String fileName = getFileName(filePart);
         String fileName2 = getFileName(filePart2);
        
         OutputStream out1 = null;
          
            InputStream filecontent = null;
            
             OutputStream out2 = null;
          
            InputStream filecontent2 = null;
            
        out1 = new FileOutputStream(new File(savepath + File.separator
                + fileName));
        out2 = new FileOutputStream(new File(savepath + File.separator
                + fileName2));
        filecontent = filePart.getInputStream();
     filecontent2 = filePart2.getInputStream();
        int read = 0;
        final byte[] bytes = new byte[1024];
 
        while ((read = filecontent.read(bytes)) != -1) {
            out1.write(bytes, 0, read);
            photo=savepath+"/"+fileName;    
        }
        int read2 = 0;
        final byte[] bytes2 = new byte[1024];
 
        while ((read2 = filecontent2.read(bytes2)) != -1) {
            out2.write(bytes2, 0, read2);
           
            photo2=savepath+"/"+fileName2;
            
            
        }
  // validate given input
  if (Advname1.isEmpty() || Advdesc1.isEmpty() || Advtime1.isEmpty()  ) {
   RequestDispatcher rd = request.getRequestDispatcher("AddAdvertisement.jsp");
   out.println("<font color=red>Please add at least 1 advertisment</font>");
   rd.include(request, response);
  } 
  else {
      int Advertiserid=0;
    Model m = new Model(); // TODO Auto-generated catch block
   m.addAdvertisement(Advertiserid, Advname1,Advdesc1 ,Integer.parseInt(Advtime1),fileName,Advname2,Advdesc2 ,Integer.parseInt(Advtime2),fileName2);
   RequestDispatcher rd = request.getRequestDispatcher("Finish.jsp");
    rd.forward(request, response);
  }
    
 }
private String getFileName(final Part part) {
    final String partHeader = part.getHeader("content-disposition");
    
    for (String content : part.getHeader("content-disposition").split(";")) {
        if (content.trim().startsWith("filename")) {
            return content.substring(
                    content.indexOf('=') + 1).trim().replace("\"", "");
        }
    }
    return null;
}
}