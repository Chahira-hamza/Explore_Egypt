package Software;


import Software.Model;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/AddanotherAdvertisment"})
public class AddAnotherAdvertisement extends HttpServlet {
public AddAnotherAdvertisement(){
    super();
}
       
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
 String id=request.getParameter("id");
 String id2=request.getParameter("id2");
 String Advname1 = request.getParameter("name1");
  
  String Advdesc1 = request.getParameter("description1");
  String Advtime1 = request.getParameter("time1");
  response.setContentType("text/html");
 PrintWriter out = response.getWriter();
  if (Advname1.isEmpty() || Advdesc1.isEmpty() || Advtime1.isEmpty()) {
         request.setAttribute("id",id);
  request.setAttribute("description1",Advdesc1);
  request.setAttribute("title",Advname1);
   request.setAttribute("time",Advtime1);
   RequestDispatcher rd = request.getRequestDispatcher("AddAnotherAdvertisement.jsp");
   out.println("<font color=red>Please add at least 1 advertisment</font>");
   rd.include(request, response);
  } 
  else {
       if ((Integer.parseInt(Advtime1))>3||Integer.parseInt(Advtime1)<=0) {
                request.setAttribute("id",id);
  request.setAttribute("description1",Advdesc1);
  request.setAttribute("title",Advname1);
  request.setAttribute("time",Advtime1);
   RequestDispatcher rd = request.getRequestDispatcher("AddAnotherAdvertisement.jsp");
   out.println("<font color=red>Please add valid time for the first advertisement</font>");
   rd.include(request, response);
  } 
       else{
      
    Model m = new Model();
    if(Integer.parseInt(id2)==1)
    {
         m.updateAdvertisementForAdv1Adding(Integer.parseInt(id), Advname1, Advdesc1 , Integer.parseInt(Advtime1),1);
    }
    else{
   m.updateAdvertisementForAdv2Adding(Integer.parseInt(id), Advname1, Advdesc1 , Integer.parseInt(Advtime1),1);
    }  
  
   RequestDispatcher rd = request.getRequestDispatcher("Finish.jsp");
    rd.forward(request, response);
       }
  }
 }
}
 

