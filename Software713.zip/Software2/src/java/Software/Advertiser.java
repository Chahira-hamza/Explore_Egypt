/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Software;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/log"})
public class Advertiser extends HttpServlet {
public Advertiser(){
    super();
}
        
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
  String name = request.getParameter("name");
  
  String pass = request.getParameter("pass");
  
  
  response.setContentType("text/html");
 PrintWriter out = response.getWriter();
 
  if (name.isEmpty() || pass.isEmpty() ) {
   RequestDispatcher rd = request.getRequestDispatcher("loginin.jsp");
   out.println("<font color=red>Please add at least 1 advertisment</font>");
   rd.include(request, response);
  } 
  else {
      int Advertiserid=0;
    Model m = new Model(); // TODO Auto-generated catch block
  Advertiserid= m.getid(name,pass);
  request.setAttribute("id",Advertiserid);
   RequestDispatcher rd = request.getRequestDispatcher("AdvertiserHomePage.jsp");
    rd.forward(request, response);
  }
    
 }
}
