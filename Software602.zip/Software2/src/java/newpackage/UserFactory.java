/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

/**
 *
 * @author User
 */
public class UserFactory {
    
    public static User getUser(int type)
    {
        switch (type) {
            case 0:
                return new Admin();
            case 1:
                return new User();
            case 2:
                return new Tourguide();
            default:
                return null;
        }
    }
    
}
