/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Software;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/ViewSite2"})
public class NextSite extends HttpServlet {
    
   
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub
 String name= request.getParameter("name2");
 Model m = new Model(); // TODO Auto-generated catch block
             int count =0;
 Site s=new Site();
        try {
      
             s= m.viewNextSite(name);
if(s.name!=null)
{
  request.setAttribute("name",s.name);
  request.setAttribute("address",s.address);
  request.setAttribute("description",s.description);
  request.setAttribute("Stime",s.start);
  request.setAttribute("Etime",s.close);
  request.setAttribute("photo",s.photo);  
  request.setAttribute("type1",s.type1); 
  request.setAttribute("type2",s.type2); 
  RequestDispatcher rd = request.getRequestDispatcher("ViewSite2.jsp");
  rd.include(request, response);
}
  else {
       RequestDispatcher rd = request.getRequestDispatcher("NoMoreSites.jsp");
   rd.include(request, response);
  }
}   
         catch (SQLException ex) {
            Logger.getLogger(AddTourGuide.class.getName()).log(Level.SEVERE, null, ex);
        }
  

  }
}